<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\SoftwareController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\AdminLoginController;
use App\Http\Controllers\Admin\LicenseController;

// Public welcome route
Route::get('/', function () {
    return view('welcome');
});

// Admin routes
Route::prefix('admin')->name('admin.')->group(function () {

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    

Route::get('dashboard/export-pdf', [DashboardController::class, 'exportPdf'])->name('dashboard.exportPdf');


    // Software routes
    Route::resource('software', SoftwareController::class);
    Route::get('software/assigned', [SoftwareController::class, 'assigned'])->name('software.assigned');
    Route::get('software/unassigned', [SoftwareController::class, 'unassigned'])->name('software.unassigned');

    // License routes linking to software assigned/unassigned
    Route::get('licenses/assigned', [SoftwareController::class, 'assigned'])->name('licenses.assigned');
    Route::get('licenses/unassigned', [SoftwareController::class, 'unassigned'])->name('licenses.unassigned');

    // Other license and budget related dashboard routes
    Route::get('licenses/expired', [DashboardController::class, 'expiredLicenses'])->name('licenses.expired');
    Route::get('licenses/expiring-soon', [DashboardController::class, 'expiringSoon'])->name('licenses.expiringSoon');
    Route::get('licenses/total-cost', [DashboardController::class, 'totalCost'])->name('licenses.totalCost');
    Route::get('budget/utilization', [DashboardController::class, 'budgetUtilization'])->name('budget.utilization');

    // Users
    Route::resource('users', UserController::class);

     Route::patch('users/{user}/deactivate', [UserController::class, 'deactivate'])
        ->name('users.deactivate');

    Route::patch('users/{user}/activate', [UserController::class, 'activate'])
        ->name('users.activate');
});

// Admin login routes
Route::get('/admin/login', [AdminLoginController::class, 'showLoginForm'])->name('admin.login');
Route::post('/admin/login', [AdminLoginController::class, 'login'])->name('admin.login.submit');
Route::post('/logout', [App\Http\Controllers\AdminLoginController::class, 'logout'])->name('logout');

// Redirect default login to admin login
Route::get('/login', function () {
    return redirect()->route('admin.login');
})->name('login');

                             // THESE ARE ROUTES FOR DASHBOARD CARDS//

// Dashboard cards routes
Route::prefix('admin')->name('admin.')->group(function () {

    // Active licenses
    Route::get('licenses/active', [LicenseController::class, 'active'])->name('licenses.active');

    // Expired licenses
    Route::get('licenses/expired', [LicenseController::class, 'expiredLicenses'])->name('licenses.expired');

    // Expiring in 30 days
    Route::get('licenses/expiring-soon', [LicenseController::class, 'expiringSoon'])->name('licenses.expiringSoon');

    // Unassigned Licenses
Route::get('licenses/unassigned', [LicenseController::class, 'unassigned'])->name('licenses.unassigned'); 

 //Assign Licenses
    Route::post('licenses/{license}/assign', [LicenseController::class, 'assign'])->name('licenses.assign');

    Route::get('/licenses/assigned', [App\Http\Controllers\Admin\LicenseController::class, 'assigned'])
    ->name('licenses.assigned');

    //Total cost spent
    Route::get('/licenses/total-cost', [\App\Http\Controllers\Admin\LicenseController::class, 'totalCost'])->name('licenses.totalCost');
});