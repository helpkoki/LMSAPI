<?php $__env->startSection('content'); ?>
<style>
  body {
    font-family: Arial, sans-serif;
    color: black;
    margin: 0;
    padding: 86px 0 0 0; /* padding top to offset navbar */
    background-color: #3c4044ff;
  }

  /* Fixed navbar */
  .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  /* Main page content container with left sidebar offset */
  .content-container {
    margin-left: 0px;
    padding: 0 14px 14px 14px;
  }

  /* Container for buttons aligned top right */
  .button-container {
    margin-top: 12px;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
  }

  /* Button styling */
  .button {
    background-color: #f0277bff;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    font-weight: 600;
    font-size: 0.9rem;
    cursor: pointer;
    transition: background-color 0.3s ease;
    box-shadow: 0 2px 4px rgba(107, 5, 5, 0.4);
  }
  .button:hover {
    background-color: #2c010cff;
  }

  /* Table container with shadow and rounded corners */
  .table-container {
    margin-top: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
    padding: 1rem;
  }

  /* Table styling */
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    color: #222;
    min-width: 1200px; /* Ensure horizontal scroll for many columns */
  }
  
  thead {
    background-color: #93e8fdff;
    font-weight: 700;
    border-bottom: 2px solid #ccc;
    text-align: left;
  }
  
  th, td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
    white-space: nowrap;
  }
  
  tbody tr:hover {
    background-color: #e0e7ff;
  }

  /* Status badge styling */
  .status-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: capitalize;
  }
  .status-active {
    background-color: #dcfce7;
    color: #22c55e;
  }
  .status-inactive {
    background-color: #fee2e2;
    color: #ef4444;
  }

  /* Action buttons styling */
  .action-button {
    padding: 4px 10px;
    margin: 0 2px;
    border: 1px solid #6b7280;
    background: #f9fafb;
    color: #374151;
    font-size: 0.75rem;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.15s;
  }
  .action-button:hover {
    background-color: #e0e7ff;
    border-color: #4338ca;
    color: #4338ca;
  }
</style>

<!-- Fixed navbar title -->
<div class="navbar">Software</div>

<!-- Main content container -->
<div class="content-container">

  <!-- Buttons aligned top right under navbar -->
  <div class="button-container">
    <a href="<?php echo e(route('admin.software.create')); ?>" class="button">+ Add New Software</a>
   <a href="<?php echo e(route('admin.dashboard.exportPdf')); ?>" class="button">Export PDF</a>



  </div>

  <!-- Table container -->
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>Product ID</th>
          <th>Name</th>
          <th>Version</th>
          <th>Manufacturer</th>
          <th>Purchase Date</th>
          <th>Number of Installations</th>
          <th>Expiry Date</th>
          <th>Vendor</th>
          <th>Assigned To</th>
          <th>Assigned</th>
          <th>Unassigned</th>
          <th>Status</th>
         
          <th>Budget</th>
          <th>Cost</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $software; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($item->product_id ?? 'N/A'); ?></td>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->version); ?></td>
            <td><?php echo e($item->manufacturer); ?></td>
            <td><?php echo e($item->last_updated ?? 'N/A'); ?></td>
           <td><?php echo e($item->number_of_installations); ?></td>

            <td><?php echo e($item->expiry_date); ?></td>
            <td><?php echo e($item->vendor ?? 'N/A'); ?></td>
            <td><?php echo e($item->assigned_to ?? '-'); ?></td>
            <td><?php echo e($item->license->assigned_licenses ?? 0); ?></td>
            <td><?php echo e(($item->license->total_licenses ?? 0) - ($item->license->assigned_licenses ?? 0)); ?></td>
            <td>
              <span class="status-badge <?php echo e($item->status === 'active' ? 'status-active' : 'status-inactive'); ?>">
                <?php echo e(ucfirst($item->status)); ?>

              </span>
            </td>
           
             <td><?php echo e($item->budget ? 'R' . number_format($item->budget, 2) : 'N/A'); ?></td><!-- add this -->
            <td><?php echo e($item->cost ? 'R' . number_format($item->cost, 2) : 'N/A'); ?></td>
            
            <td>
              <a href="<?php echo e(route('admin.software.edit', $item->id)); ?>" class="action-button">Edit</a>
              <form action="<?php echo e(route('admin.software.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="action-button" onclick="return confirm('Are you sure?')">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
      <td colspan="15" class="text-center">No software found.</td> <!-- Adjust colspan -->
    </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</div>

<script>
  // Dummy function for Export PDF button - replace with actual implementation
  function exportPDF() {
    alert('Export to PDF functionality is not implemented yet.');
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\IT-Asset-System-master (2) - Copy\IT-Asset-System-master\resources\views/admin/software/index.blade.php ENDPATH**/ ?>