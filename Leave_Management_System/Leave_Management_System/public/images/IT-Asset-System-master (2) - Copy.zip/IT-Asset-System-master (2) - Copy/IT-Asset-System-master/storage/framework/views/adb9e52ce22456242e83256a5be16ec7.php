<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-6">Edit User</h1>

<form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST" class="bg-white p-6 rounded-xl shadow max-w-lg">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-4">
        <label class="block font-semibold">Name</label>
        <input type="text" name="name" value="<?php echo e($user->name); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Email</label>
        <input type="email" name="email" value="<?php echo e($user->email); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Password (leave blank if unchanged)</label>
        <input type="password" name="password" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Role</label>
        <select name="role" class="w-full border rounded px-3 py-2">
            <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
            <option value="viewer" <?php echo e($user->role === 'viewer' ? 'selected' : ''); ?>>Viewer</option>
        </select>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Status</label>
        <select name="status" class="w-full border rounded px-3 py-2">
            <option value="active" <?php echo e($user->status === 'active' ? 'selected' : ''); ?>>Active</option>
            <option value="inactive" <?php echo e($user->status === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
        </select>
    </div>

    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
        Update
    </button>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="ml-2 text-gray-600 hover:underline">Cancel</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\IT-Asset-System-master (2) - Copy\IT-Asset-System-master\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>