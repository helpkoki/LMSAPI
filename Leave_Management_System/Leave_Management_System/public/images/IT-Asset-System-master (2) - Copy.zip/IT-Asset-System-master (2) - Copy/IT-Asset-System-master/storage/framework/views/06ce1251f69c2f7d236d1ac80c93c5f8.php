<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
    <title>Your Account Details</title>
</head>
<body>
    <h2>Hello <?php echo e($user->name); ?>,</h2>
    <p>Your account has been created. Here are your login details:</p>
    <ul>
        <li>Email: <?php echo e($user->email); ?></li>
        <li>Password: <?php echo e($password); ?></li>
    </ul>
    <p>Please log in and change your password immediately for security.</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\IT-Asset-System-master (2) - Copy\IT-Asset-System-master\resources\views/emails/user_registered.blade.php ENDPATH**/ ?>