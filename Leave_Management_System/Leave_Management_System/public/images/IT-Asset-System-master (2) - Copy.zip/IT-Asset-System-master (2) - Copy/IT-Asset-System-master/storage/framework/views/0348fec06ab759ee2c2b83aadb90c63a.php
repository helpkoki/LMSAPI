<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-6">Edit Software</h1>

<form action="<?php echo e(route('admin.software.update', $software->id)); ?>" method="POST" class="bg-white p-6 rounded-xl shadow max-w-lg">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-4">
        <label class="block font-semibold">Name</label>
        <input type="text" name="name" value="<?php echo e($software->name); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Version</label>
        <input type="text" name="version" value="<?php echo e($software->version); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Manufacturer</label>
        <input type="text" name="manufacturer" value="<?php echo e($software->manufacturer); ?>" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Last Updated</label>
        <input type="date" name="last_updated" value="<?php echo e($software->last_updated); ?>" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Expiry Date</label>
        <input type="date" name="expiry_date" value="<?php echo e($software->expiry_date); ?>" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Total Licenses</label>
        <input type="number" name="total_licenses" value="<?php echo e($software->license->total_licenses ?? 0); ?>" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Vendor</label>
        <input type="text" name="vendor" value="<?php echo e($software->vendor); ?>" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Status</label>
        <select name="status" class="w-full border rounded px-3 py-2">
            <option value="active" <?php echo e($software->status === 'active' ? 'selected' : ''); ?>>Active</option>
            <option value="inactive" <?php echo e($software->status === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
        </select>
    </div>

    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
        Update
    </button>
    <a href="<?php echo e(route('admin.software.index')); ?>" class="ml-2 text-gray-600 hover:underline">Cancel</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\IT-Asset-System-master (2) - Copy\IT-Asset-System-master\resources\views/admin/software/edit.blade.php ENDPATH**/ ?>