<?php $__env->startSection('content'); ?>
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #ebeceeff;
    margin: 0;
    padding: 20px;
    color: black;
  }

   .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  .form-container {
    max-width: 700px;
    background: white;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    margin: 80px auto;
  }
  h1 {
    font-weight: 700;
    margin-bottom: 1.5rem;
    font-size: 2rem;
  }
  label {
    display: block;
    font-weight: 600;
    margin-bottom: 0.375rem;
  }
  input[type="text"],
  input[type="number"],
  input[type="date"],
  select {
    width: 100%;
    border: 1px solid #ccc;
    border-radius: 6px;
    padding: 0.5rem 0.75rem;
    font-size: 1rem;
    margin-bottom: 0.75rem;
    box-sizing: border-box;
  }
  .error {
    color: #ef4444;
    font-size: 0.875rem;
    margin-top: -0.5rem;
    margin-bottom: 0.75rem;
  }
  button {
    background-color: #2563eb;
    color: white;
    font-weight: 600;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    font-size: 1rem;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  button:hover {
    background-color: #1e40af;
  }
  .cancel-link {
    margin-left: 1rem;
    color: #4b5563;
    font-weight: 500;
    text-decoration: underline;
    cursor: pointer;
  }
</style>

<div class="navbar">Add New Softwaree</div>

<div class="form-container">
  

  
  <?php if($errors->any()): ?>
    <div class="error" style="margin-bottom: 1rem;">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('admin.software.store')); ?>" method="POST" novalidate>
    <?php echo csrf_field(); ?>

    
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="version">Version</label>
    <input type="text" name="version" id="version" value="<?php echo e(old('version')); ?>" required>
    <?php $__errorArgs = ['version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="manufacturer">Manufacturer</label>
    <input type="text" name="manufacturer" id="manufacturer" value="<?php echo e(old('manufacturer')); ?>">
    <?php $__errorArgs = ['manufacturer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="purchase_date">Purchase Date</label>
    <input type="date" name="last_updated" id="plast_updated" value="<?php echo e(old('last_updated')); ?>">
    <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

   
    <label for="expiry_date">Expiry Date</label>
    <input type="date" name="expiry_date" id="expiry_date" value="<?php echo e(old('expiry_date')); ?>">
    <?php $__errorArgs = ['expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="vendor">Vendor</label>
    <input type="text" name="vendor" id="vendor" value="<?php echo e(old('vendor')); ?>">
    <?php $__errorArgs = ['vendor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

   <label for="assigned_to">Assigned To</label>
<select name="assigned_to" id="assigned_to">
  <option value="">-- Select User --</option>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($user->name); ?>" <?php echo e(old('assigned_to') == $user->name ? 'selected' : ''); ?>>
      <?php echo e($user->name); ?>

    </option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="total_licenses">Total Licenses</label>
    <input type="number" name="total_licenses" id="total_licenses" value="<?php echo e(old('total_licenses', 0)); ?>" min="0">
    <?php $__errorArgs = ['total_licenses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="assigned_licenses">Assigned Licenses</label>
    <input type="number" name="assigned_licenses" id="assigned_licenses" value="<?php echo e(old('assigned_licenses', 0)); ?>" min="0">
    <?php $__errorArgs = ['assigned_licenses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label for="status">Status</label>
    <select name="status" id="status">
      <option value="active" <?php echo e(old('status') === 'active' ? 'selected' : ''); ?>>Active</option>
      <option value="inactive" <?php echo e(old('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
    </select>
    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    

    <label for="budget">Budget (ZAR)</label>
    <input type="number" name="budget" id="budget" step="0.01" value="<?php echo e(old('budget')); ?>">
     <?php $__errorArgs = ['budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


    <label for="cost">Cost (ZAR)</label>
    <input type="number" name="cost" id="cost" step="0.01" value="<?php echo e(old('cost')); ?>">
    <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <button type="submit">Save</button>
    <a href="<?php echo e(route('admin.software.index')); ?>" class="cancel-link">Cancel</a>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\IT-Asset-System-master (2) - Copy\IT-Asset-System-master\resources\views/admin/software/create.blade.php ENDPATH**/ ?>