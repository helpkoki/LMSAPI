<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class Software extends Model
{
    use HasFactory;
 protected $fillable = [
        'product_id',
        'name',
        'version',
        'manufacturer',
        'last_updated',
        'expiry_date',
        'status',
        'vendor',
        'assigned_to',
        'total_licenses',
        'assigned_licenses',
        'renewal_cost',
        'cost',
        'budget'
    ];


    public function license()
    {
        return $this->hasOne(License::class);
    }

    public function getNumberOfInstallationsAttribute()
{
    $assigned = $this->license->assigned_licenses ?? 0;
    $total = $this->license->total_licenses ?? 0;
    return "$assigned of $total";
}


    public function assignments()
    {
        return $this->hasMany(Assignment::class);
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'assignments');
    }
}