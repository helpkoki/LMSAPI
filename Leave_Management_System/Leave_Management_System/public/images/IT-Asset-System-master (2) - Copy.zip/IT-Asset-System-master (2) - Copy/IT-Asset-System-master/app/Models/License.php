<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class License extends Model
{
    use HasFactory;

    protected $fillable = [
        'software_id',
        'user_id',
        'total_licenses',
        'assigned_licenses',
        'status',        // active, expired, etc.
        'manufacturer',
        'expiry_date'
    ];

    public function software()
    {
        return $this->belongsTo(Software::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    
}