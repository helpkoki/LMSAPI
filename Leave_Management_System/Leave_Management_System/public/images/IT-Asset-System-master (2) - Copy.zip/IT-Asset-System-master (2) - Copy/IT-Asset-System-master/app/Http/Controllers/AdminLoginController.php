<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class AdminLoginController extends Controller
{
    // Show the login form
    public function showLoginForm()
    {
        return view('admin.login'); // adjust if needed
    }

    // Handle login for admin and viewer
    public function login(Request $request)
    {
        $role = $request->input('role');

        if ($role === 'admin') {
            $request->validate([
                'admin_number' => ['required', 'string'],
                'admin_password' => ['required', 'string'],
            ]);

            if ($request->admin_number === '12345' && $request->admin_password === 'password24@09D') {
                Auth::guard('web')->loginUsingId(1); // admin assumed user ID 1
                $request->session()->regenerate();

                return redirect()->intended('/admin/dashboard');
            }

            return back()->withErrors([
                'admin_number' => 'The provided credentials do not match our records.',
            ])->onlyInput('admin_number');
        }

        if ($role === 'viewer') {
            $request->validate([
                'viewer_email' => ['required', 'email'],
                'viewer_password' => ['required', 'string'],
            ]);

            $user = User::where('email', $request->viewer_email)
                ->where('role', 'viewer')
                ->where('status', 'active')
                ->first();

            if ($user && Hash::check($request->viewer_password, $user->password)) {
                Auth::login($user);
                $request->session()->regenerate();

                return redirect()->intended('/viewer/dashboard'); // adjust route as needed
            }

            return back()->withErrors([
                'viewer_email' => 'The provided credentials do not match our records.',
            ])->onlyInput('viewer_email');
        }

        return back()->withErrors([
            'role' => 'Please select a valid role.',
        ]);
    }

    // Show admin dashboard
    public function dashboard()
    {
        return view('admin.dashboard');
    }

    // Logout admin or viewer
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/admin/login');
    }
}
