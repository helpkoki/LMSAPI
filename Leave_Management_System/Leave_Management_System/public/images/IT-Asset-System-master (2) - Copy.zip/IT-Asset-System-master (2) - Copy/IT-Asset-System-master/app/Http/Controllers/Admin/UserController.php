<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserRegistered;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('admin.users.index', compact('users'));
    }

    public function create()
    {
        return view('admin.users.create');
    }

  public function store(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|email|unique:users,email',
        'password' => 'required|string|min:6',
        'role' => 'required|string',
        'department' => 'nullable|string'
    ]);

    $password = $request->password;

    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => bcrypt($password),
        'department' => $request->department,
        'role' => $request->role,
        'status' => 'active',
    ]);

    // Send email
    Mail::to($user->email)->send(new UserRegistered($user, $password));

    return redirect()->back()->with('success', 'User created and email sent.');
}

    public function deactivate(User $user)
    {
        $user->update(['status' => 'inactive']);
        return redirect()->route('admin.users.index')->with('success', 'User deactivated.');
    }

    public function activate(User $user)
    {
        $user->update(['status' => 'active']);
        return redirect()->route('admin.users.index')->with('success', 'User activated.');
    }

    public function show(User $user)
    {
        return view('admin.users.show', compact('user'));
    }

    public function edit(User $user)
    {
        return view('admin.users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'department' => $request->department, // add this line
            'role' => $request->role,
            'status' => $request->status ?? 'active',
        ]);

        return redirect()->back()->with('success', 'User updated successfully.');
    }

    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->back()->with('success', 'User deleted successfully.');
    }
}
