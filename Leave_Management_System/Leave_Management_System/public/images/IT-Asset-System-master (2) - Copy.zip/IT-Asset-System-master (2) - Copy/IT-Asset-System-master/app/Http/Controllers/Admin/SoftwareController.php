<?php

namespace App\Http\Controllers\Admin;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Software;
use App\Models\License;

class SoftwareController extends Controller
{
    /**
     * Display a listing of software.
     */
    public function index()
    {
        $software = Software::with('license')->get();
        return view('admin.software.index', compact('software'));
    }

    /**
     * Show the form for creating new software.
     */
    public function create()
    {
          $users = User::where('status', 'active')->orderBy('name')->get();
    return view('admin.software.create', compact('users'));
        return view('admin.software.create');
    }



    /**
     * Store newly created software in database.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
           
            'name' => 'required|string|max:255',
            'version' => 'required|string|max:255',
            'manufacturer' => 'nullable|string|max:255',
            'last_updated' => 'nullable|date',
            'expiry_date' => 'nullable|date',
            'status' => 'required|in:active,inactive',
            'vendor' => 'nullable|string|max:255',
            'assigned_to' => 'nullable|string|max:255',
            'total_licenses' => 'nullable|integer|min:0',
            'assigned_licenses' => 'nullable|integer|min:0',
            'renewal_cost' => 'nullable|numeric',
            'cost' => 'nullable|numeric',
            'budget' => 'nullable|numeric',
        ]);

        // Generate next sequential number
    $lastSoftware = Software::orderBy('id', 'desc')->first();

    if ($lastSoftware && preg_match('/P001-(\d+)/', $lastSoftware->product_id, $matches)) {
        $lastNumber = (int) $matches[1];
        $nextNumber = $lastNumber + 1;
    } else {
        $nextNumber = 1;
    }

    // Format number with leading zeros e.g. 001, 002
    $formattedNumber = str_pad($nextNumber, 3, '0', STR_PAD_LEFT);

    // Compose product_id
    $validated['product_id'] = "P001-" . $formattedNumber;


        $software = Software::create($validated);

        License::create([
            'software_id' => $software->id,
            'total_licenses' => $validated['total_licenses'] ?? 0,
            'assigned_licenses' => $validated['assigned_licenses'] ?? 0,
        ]);

        return redirect()->route('admin.software.index')
            ->with('success', 'Software added successfully.');
    }

    /**
     * Show the software details.
     */
    public function show(Software $software)
    {
        return view('admin.software.show', compact('software'));
    }

    /**
     * Show the form for editing software.
     */
    public function edit(Software $software)
    {
        return view('admin.software.edit', compact('software'));
    }

    /**
     * Update the software in database.
     */
    public function update(Request $request, Software $software)
    {
        $validated = $request->validate([
            'product_id' => 'nullable|string|max:255',
            'name' => 'required|string|max:255',
            'version' => 'required|string|max:255',
            'manufacturer' => 'nullable|string|max:255',
            'last_updated' => 'nullable|date',
            'expiry_date' => 'nullable|date',
            'status' => 'required|in:active,inactive',
            'vendor' => 'nullable|string|max:255',
            'assigned_to' => 'nullable|string|max:255',
            'total_licenses' => 'nullable|integer|min:0',
            'assigned_licenses' => 'nullable|integer|min:0',
            'renewal_cost' => 'nullable|numeric',
            'cost' => 'nullable|numeric',
            'budget' => 'nullable|numeric',
        ]);

        $software->update($validated);

        // Optionally update license if related fields updated

        return redirect()->route('admin.software.index')
            ->with('success', 'Software updated successfully.');
    }

    /**
     * Delete software.
     */
    public function destroy(Software $software)
    {
        $software->delete();

        return redirect()->route('admin.software.index')
            ->with('success', 'Software deleted successfully.');
    }
}
