<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\License;
use App\Models\Software;
use Barryvdh\DomPDF\Facade\Pdf;
class DashboardController extends Controller
{



 public function exportPdf()
    {
        $software = Software::with('license')->get();
        $totalLicenses = $software->sum(fn($s) => $s->license->total_licenses ?? 0);

        $pdf = Pdf::loadView('admin.dashboard_pdf', compact('software', 'totalLicenses'));

        return $pdf->download('dashboard_report.pdf');
    }
    public function index()
    {
        // 1. Total License Purchases
        $totalLicenses = License::sum('total_licenses');

        // 2. Active Licenses (assumed = assigned_licenses in your schema)
        $activeLicenses = License::sum('assigned_licenses');

        // 3. Expired Licenses
        $expiredLicenses = Software::where('expiry_date', '<', now())->count();

        // 4. Licenses Expiring within 30 days
        $expiringLicenses = Software::whereBetween('expiry_date', [now(), now()->addDays(30)])->count();

        // 5. Total Cost Spend (sum of all software costs)
        $totalCost = Software::sum('cost');

        // 6. Budget Utilization (dummy example: assume each software has `budget` column)
        $totalBudget = Software::sum('budget');
        $budgetUtilization = $totalBudget > 0 
            ? round(($totalCost / $totalBudget) * 100, 2) 
            : 0;

        // 7. Assigned Licenses
        $assignedLicenses = License::sum('assigned_licenses');

        // 8. Unassigned Licenses
        $unassignedLicenses = License::sum('total_licenses') - $assignedLicenses;

        // Chart data (Manufacturer cost breakdown)
        $manufacturerCosts = Software::selectRaw('manufacturer, SUM(cost) as total')
            ->groupBy('manufacturer')
            ->pluck('total', 'manufacturer')
            ->toArray();

        // Chart data (Budget vs Spending per software)
        $budgetData = Software::select('name', 'cost', 'budget')
            ->get()
            ->mapWithKeys(function ($software) {
                return [
                    $software->name => [
                        'spent' => $software->cost,
                        'budget' => $software->budget ?? 0
                    ]
                ];
            })
            ->toArray();

        return view('admin.dashboard', compact(
            'totalLicenses',
            'activeLicenses',
            'expiredLicenses',
            'expiringLicenses',
            'totalCost',
            'budgetUtilization',
            'assignedLicenses',
            'unassignedLicenses',
            'manufacturerCosts',
            'budgetData'
        ));
    }
}
