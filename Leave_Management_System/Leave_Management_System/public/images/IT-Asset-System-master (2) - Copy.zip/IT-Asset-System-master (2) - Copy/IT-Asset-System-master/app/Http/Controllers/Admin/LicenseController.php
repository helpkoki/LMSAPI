<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\License;

class LicenseController extends Controller
{
    /**
     * Display a listing of all licenses.
     */
    public function index()
    {
        $licenses = License::with('user', 'software')->get(); // include software if needed
        return view('admin.licenses.index', compact('licenses'));
    }

    /**
     * Display all active licenses.
     */
    public function active()
    {
        $licenses = License::where('status', 'active')
            ->with('user', 'software')
            ->get();

        return view('admin.licenses.active', compact('licenses'));
    }

    /**
     * Display a single license.
     */
    public function show($id)
    {
        $license = License::with('user', 'software')->findOrFail($id);
        return view('admin.licenses.show', compact('license'));
    }



    public function expiringSoon()
{
    $today = now();
    $thirtyDays = now()->addDays(30);

    $licenses = License::with('software', 'user')
        ->whereHas('software', function($query) use ($today, $thirtyDays) {
            $query->whereBetween('expiry_date', [$today, $thirtyDays]);
        })
        ->orderBy('id', 'asc') // order by license id or software name
        ->get();

    return view('admin.licenses.expiring_soon', compact('licenses'));
}
public function expiredLicenses()
{
    // Fetch licenses whose related software is expired
    $expiredLicenses = License::with('software', 'user')
        ->whereHas('software', function($query) {
            $query->where('expiry_date', '<', now());
        })
        ->get();

    return view('admin.licenses.expired', compact('expiredLicenses'));
}

public function assigned()
{
    $licenses = License::with('software', 'user')
        ->where('assigned_licenses', '>', 0)
        ->get();

    return view('admin.licenses.assigned', compact('licenses'));
}

public function unassigned()
{
    $licenses = License::with('software')
        ->whereColumn('assigned_licenses', '<', 'total_licenses') // check remaining licenses
        ->get();

    return view('admin.licenses.unassigned', compact('licenses'));
}

public function assign(Request $request, License $license)
{
    $request->validate([
        'assign_count' => 'required|integer|min:1|max:' . ($license->total_licenses - $license->assigned_licenses),
    ]);

    $assignCount = $request->assign_count;

    // Update the assigned_licenses
    $license->assigned_licenses += $assignCount;
    $license->save();

    return redirect()->back()->with('success', "$assignCount licenses assigned successfully.");
}

public function totalCost()
{
    // Load all licenses with their software
    $licenses = License::with('software')->get();

    return view('admin.licenses.total_cost', compact('licenses'));
}
}