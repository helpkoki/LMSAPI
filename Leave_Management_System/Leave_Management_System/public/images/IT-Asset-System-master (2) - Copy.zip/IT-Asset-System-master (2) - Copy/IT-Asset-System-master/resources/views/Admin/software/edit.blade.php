@extends('layouts.admin')

@section('content')
<h1 class="text-2xl font-bold mb-6">Edit Software</h1>

<form action="{{ route('admin.software.update', $software->id) }}" method="POST" class="bg-white p-6 rounded-xl shadow max-w-lg">
    @csrf
    @method('PUT')

    <div class="mb-4">
        <label class="block font-semibold">Name</label>
        <input type="text" name="name" value="{{ $software->name }}" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Version</label>
        <input type="text" name="version" value="{{ $software->version }}" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Manufacturer</label>
        <input type="text" name="manufacturer" value="{{ $software->manufacturer }}" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Last Updated</label>
        <input type="date" name="last_updated" value="{{ $software->last_updated }}" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Expiry Date</label>
        <input type="date" name="expiry_date" value="{{ $software->expiry_date }}" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Total Licenses</label>
        <input type="number" name="total_licenses" value="{{ $software->license->total_licenses ?? 0 }}" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Vendor</label>
        <input type="text" name="vendor" value="{{ $software->vendor }}" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Status</label>
        <select name="status" class="w-full border rounded px-3 py-2">
            <option value="active" {{ $software->status === 'active' ? 'selected' : '' }}>Active</option>
            <option value="inactive" {{ $software->status === 'inactive' ? 'selected' : '' }}>Inactive</option>
        </select>
    </div>

    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
        Update
    </button>
    <a href="{{ route('admin.software.index') }}" class="ml-2 text-gray-600 hover:underline">Cancel</a>
</form>
@endsection