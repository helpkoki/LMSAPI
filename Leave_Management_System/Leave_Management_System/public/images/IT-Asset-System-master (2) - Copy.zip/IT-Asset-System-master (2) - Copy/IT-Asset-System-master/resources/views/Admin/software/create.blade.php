@extends('layouts.admin')

@section('content')
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #ebeceeff;
    margin: 0;
    padding: 20px;
    color: black;
  }

   .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  .form-container {
    max-width: 700px;
    background: white;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    margin: 80px auto;
  }
  h1 {
    font-weight: 700;
    margin-bottom: 1.5rem;
    font-size: 2rem;
  }
  label {
    display: block;
    font-weight: 600;
    margin-bottom: 0.375rem;
  }
  input[type="text"],
  input[type="number"],
  input[type="date"],
  select {
    width: 100%;
    border: 1px solid #ccc;
    border-radius: 6px;
    padding: 0.5rem 0.75rem;
    font-size: 1rem;
    margin-bottom: 0.75rem;
    box-sizing: border-box;
  }
  .error {
    color: #ef4444;
    font-size: 0.875rem;
    margin-top: -0.5rem;
    margin-bottom: 0.75rem;
  }
  button {
    background-color: #2563eb;
    color: white;
    font-weight: 600;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    font-size: 1rem;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  button:hover {
    background-color: #1e40af;
  }
  .cancel-link {
    margin-left: 1rem;
    color: #4b5563;
    font-weight: 500;
    text-decoration: underline;
    cursor: pointer;
  }
</style>

<div class="navbar">Add New Softwaree</div>

<div class="form-container">
  

  {{-- Show all validation errors --}}
  @if($errors->any())
    <div class="error" style="margin-bottom: 1rem;">
      <ul>
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
  @endif

  <form action="{{ route('admin.software.store') }}" method="POST" novalidate>
    @csrf

    
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="{{ old('name') }}" required>
    @error('name')<div class="error">{{ $message }}</div>@enderror

    <label for="version">Version</label>
    <input type="text" name="version" id="version" value="{{ old('version') }}" required>
    @error('version')<div class="error">{{ $message }}</div>@enderror

    <label for="manufacturer">Manufacturer</label>
    <input type="text" name="manufacturer" id="manufacturer" value="{{ old('manufacturer') }}">
    @error('manufacturer')<div class="error">{{ $message }}</div>@enderror

    <label for="purchase_date">Purchase Date</label>
    <input type="date" name="last_updated" id="plast_updated" value="{{ old('last_updated') }}">
    @error('purchase_date')<div class="error">{{ $message }}</div>@enderror

   
    <label for="expiry_date">Expiry Date</label>
    <input type="date" name="expiry_date" id="expiry_date" value="{{ old('expiry_date') }}">
    @error('expiry_date')<div class="error">{{ $message }}</div>@enderror

    <label for="vendor">Vendor</label>
    <input type="text" name="vendor" id="vendor" value="{{ old('vendor') }}">
    @error('vendor')<div class="error">{{ $message }}</div>@enderror

   <label for="assigned_to">Assigned To</label>
<select name="assigned_to" id="assigned_to">
  <option value="">-- Select User --</option>
  @foreach($users as $user)
    <option value="{{ $user->name }}" {{ old('assigned_to') == $user->name ? 'selected' : '' }}>
      {{ $user->name }}
    </option>
  @endforeach
</select>
@error('assigned_to')<div class="error">{{ $message }}</div>@enderror

    <label for="total_licenses">Total Licenses</label>
    <input type="number" name="total_licenses" id="total_licenses" value="{{ old('total_licenses', 0) }}" min="0">
    @error('total_licenses')<div class="error">{{ $message }}</div>@enderror

    <label for="assigned_licenses">Assigned Licenses</label>
    <input type="number" name="assigned_licenses" id="assigned_licenses" value="{{ old('assigned_licenses', 0) }}" min="0">
    @error('assigned_licenses')<div class="error">{{ $message }}</div>@enderror

    <label for="status">Status</label>
    <select name="status" id="status">
      <option value="active" {{ old('status') === 'active' ? 'selected' : '' }}>Active</option>
      <option value="inactive" {{ old('status') === 'inactive' ? 'selected' : '' }}>Inactive</option>
    </select>
    @error('status')<div class="error">{{ $message }}</div>@enderror

    

    <label for="budget">Budget (ZAR)</label>
    <input type="number" name="budget" id="budget" step="0.01" value="{{ old('budget') }}">
     @error('budget')<div class="error">{{ $message }}</div>@enderror


    <label for="cost">Cost (ZAR)</label>
    <input type="number" name="cost" id="cost" step="0.01" value="{{ old('cost') }}">
    @error('cost')<div class="error">{{ $message }}</div>@enderror

    <button type="submit">Save</button>
    <a href="{{ route('admin.software.index') }}" class="cancel-link">Cancel</a>
  </form>
</div>
@endsection
