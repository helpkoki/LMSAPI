@extends('layouts.admin')

@section('content')
<style>
  body {
    font-family: Arial, sans-serif;
    color: black;
    margin: 0;
    padding: 86px 14px 14px 14px;
    background-color: #3c4044ff;
  }

  .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  .table-container {
    margin-top: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
    padding: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    color: #222;
    min-width: 800px;
  }

  thead {
    background: linear-gradient(135deg, #ec4899, #be185d, #831843); /* pink gradient */
    color: white;
    font-weight: 700;
    border-bottom: 2px solid #ccc;
    text-align: left;
  }

  th, td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
  }

  tbody tr:hover {
    background-color: #fcc7f5ff; /* lighter pink on hover */
  }

  .text-center {
    text-align: center;
  }

  .text-pink-600 {
    color: #be185d;
    font-weight: 600;
  }
</style>

<div class="navbar">Unassigned Licenses</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>License Name</th>
                <th>Software</th>
                <th>Total Licenses</th>
                <th>Assigned Licenses</th>
                <th>Remaining</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse($licenses as $license)
                <tr>
                    <td>{{ $license->license_name ?? 'N/A' }}</td>
                    <td>{{ $license->software->name ?? '-' }}</td>
                    <td>{{ $license->total_licenses }}</td>
                    <td>{{ $license->assigned_licenses }}</td>
                    <td>{{ $license->total_licenses - $license->assigned_licenses }}</td>
                    <td class="text-pink-600">
                        @if($license->assigned_licenses < $license->total_licenses)
                            Unassigned
                        @else
                            Fully Assigned
                        @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6" class="text-center">No unassigned licenses found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection