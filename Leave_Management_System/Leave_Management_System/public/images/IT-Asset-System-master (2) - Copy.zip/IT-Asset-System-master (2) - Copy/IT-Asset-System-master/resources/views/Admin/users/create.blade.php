@extends('layouts.admin')

@section('content')
<style>
    /* Container styling */
    .form-container {
        background-color: white;
        padding: 24px;
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        max-width: 600px;
        margin: 0 auto;
        font-family: Arial, sans-serif;
        margin-top:100px;
    }
    h1 {
        font-size: 28px;
        font-weight: bold;
        margin-bottom: 24px;
        text-align: center;
    }

    .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

    label {
        display: block;
        font-weight: 600;
        margin-bottom: 8px;
        color: #333;
    }
    input[type="text"],
    input[type="email"],
    input[type="password"],
    select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 16px;
        box-sizing: border-box;
        margin-bottom: 20px;
        transition: border-color 0.3s ease;
    }
    input[type="text"]:focus,
    input[type="email"]:focus,
    input[type="password"]:focus,
    select:focus {
        border-color: #007BFF;
        outline: none;
    }
    .btn-submit {
        background-color: #007BFF;
        color: white;
        padding: 12px 24px;
        font-size: 18px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        display: inline-block;
    }
    .btn-submit:hover {
        background-color: #0056b3;
    }
    .btn-cancel {
        margin-left: 16px;
        color: #555;
        font-size: 16px;
        text-decoration: none;
        line-height: 40px;
    }
    .btn-cancel:hover {
        text-decoration: underline;
    }
</style>

<div class="navbar">Add New User</div>


<form action="{{ route('admin.users.store') }}" method="POST" class="form-container">
    @csrf

    <label for="name">Name</label>
    <input id="name" type="text" name="name" required>

    <label for="email">Email</label>
    <input id="email" type="email" name="email" required>

    <label for="password">Password</label>
    <input id="password" type="password" name="password" required>

    <label for="department">Department</label>
    <input id="department" type="text" name="department" required>

    <label for="role">Role</label>
    <select id="role" name="role">
        <option value="admin">Admin</option>
        <option value="viewer">Viewer</option>
    </select>

    <label for="status">Status</label>
    <select id="status" name="status">
        <option value="active" selected>Active</option>
        <option value="inactive">Inactive</option>
    </select>

    <button type="submit" class="btn-submit">Save</button>
    <a href="{{ route('admin.users.index') }}" class="btn-cancel">Cancel</a>
</form>
@endsection
