<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: white;
      margin: 0;
      display: flex;
      height: 100vh;
      align-items: center;
      justify-content: center;
    }
    .login-container {
      background: #fff;
      padding: 3rem 4rem;
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
      width: 100%;
      max-width: 700px;
    }
    .logo {
      display: block;
      margin: 0 auto 1.5rem;
      width: 400px;
      height: auto;
    }
    .login-container h2 {
      font-size: 1.8rem;
      font-weight: 600;
      text-align: center;
      margin-bottom: 2rem;
      color: #333;
    }
    .form-group {
      margin-bottom: 1.8rem;
      max-width: 500px;
      margin-left: auto;
      margin-right: auto;
    }
    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      font-size: 1rem;
      color: #444;
    }
    input[type="text"],
    input[type="password"],
    input[type="email"] {
      width: 100%;
      padding: 0.9rem;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 1rem;
      transition: border 0.3s ease;
      box-sizing: border-box;
    }
    input[type="text"]:focus,
    input[type="password"]:focus,
    input[type="email"]:focus {
      border-color: #0a0a0aff;
      outline: none;
    }
    .error-box {
      background: #fee2e2;
      color: #b91c1c;
      padding: 0.8rem;
      border-radius: 8px;
      font-size: 0.95rem;
      margin-bottom: 1.2rem;
      text-align: center;
      max-width: 500px;
      margin-left: auto;
      margin-right: auto;
    }
    .login-btn {
      display: block;
      width: 100%;
      padding: 1rem;
      background: linear-gradient(135deg, #0e022bff, #090511ff);
      color: #fff;
      font-size: 1.1rem;
      font-weight: 600;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease, transform 0.2s;
      max-width: 500px;
      margin: 0 auto;
    }
    .login-btn:hover {
      background: linear-gradient(135deg, #21172bff, #524c5eff);
      transform: scale(1.02);
    }
    .login-btn:active {
      transform: scale(0.98);
    }
    .role-selector {
      max-width: 500px;
      margin: 0 auto 2rem;
      display: flex;
      justify-content: center;
      gap: 2rem;
      color: #444;
      font-weight: 600;
    }

   .role-selector input[type="radio"] {
    -webkit-appearance: none; /* Safari and Chrome */
    -moz-appearance: none;    /* Firefox */
    appearance: none;         /* Modern browsers */
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background-color: #e0e0e0; /* Light grey background */
   
    position: relative;
    outline: none;
    margin-right: 6px;
}

.role-selector input[type="radio"]:checked {
    background-color: #007bff; /* Blue fill when checked */
}




  </style>
</head>
<body>

  <div class="login-container">
    <img src="{{ asset('images/asset-logo.jpg') }}" alt="Asset Logo" class="logo" />
    <h2>Login</h2>

    @if ($errors->any())
      <div class="error-box">
        {{ $errors->first() }}
      </div>
    @endif

    <form action="{{ route('admin.login.submit') }}" method="POST" id="loginForm">
      @csrf

      <div class="role-selector">
        <label>
          <input type="radio" name="role" value="admin" checked /> Admin
        </label>
        <label>
          <input type="radio" name="role" value="viewer" /> Viewer
        </label>
      </div>

      <!-- Admin fields -->
      <div class="form-group admin-field">
        <label for="admin_number">Admin Number</label>
        <input type="text" name="admin_number" id="admin_number" value="{{ old('admin_number') }}" />
      </div>
      <div class="form-group admin-field">
        <label for="admin_password">Password</label>
        <input type="password" name="admin_password" id="admin_password" />
      </div>

      <!-- Viewer fields -->
      <div class="form-group viewer-field" style="display:none;">
        <label for="viewer_email">Email</label>
        <input type="email" name="viewer_email" id="viewer_email" value="{{ old('viewer_email') }}" />
      </div>
      <div class="form-group viewer-field" style="display:none;">
        <label for="viewer_password">Password</label>
        <input type="password" name="viewer_password" id="viewer_password" />
      </div>

      <button type="submit" class="login-btn">Login</button>
    </form>
  </div>

  <script>
    const roleRadios = document.querySelectorAll('input[name="role"]');
    const adminFields = document.querySelectorAll('.admin-field');
    const viewerFields = document.querySelectorAll('.viewer-field');

    function toggleFields() {
      const selectedRole = document.querySelector('input[name="role"]:checked').value;
      if (selectedRole === 'admin') {
        adminFields.forEach(f => f.style.display = '');
        viewerFields.forEach(f => f.style.display = 'none');
      } else {
        adminFields.forEach(f => f.style.display = 'none');
        viewerFields.forEach(f => f.style.display = '');
      }
    }

    roleRadios.forEach(radio => {
      radio.addEventListener('change', toggleFields);
    });

    toggleFields(); // Initial toggle on page load
  </script>
</body>
</html>
