<!DOCTYPE html>
<html>
<head>
  <title>Dashboard Report</title>
  <style>
    body { 
      font-family: DejaVu Sans, sans-serif;
      font-size: 10px; /* smaller font to fit more content */
      margin: 10px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed; /* important for fixed column widths */
      word-wrap: break-word;
      font-size: 10px;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 4px 6px;
      overflow-wrap: break-word;
      white-space: normal; /* allow text wrap */
      vertical-align: top;
    }
    th {
      background: #eee;
      text-align: left;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <h1 style="font-size: 14px;">Dashboard Report</h1>
  <p>Total Licenses: {{ $totalLicenses }}</p>
  <table>
    <thead>
      <tr>
        <th style="width: 8%;">Product ID</th>
        <th style="width: 10%;">Name</th>
        <th style="width: 6%;">Version</th>
        <th style="width: 10%;">Manufacturer</th>
        <th style="width: 8%;">Purchase Date</th>
        <th style="width: 8%;">Expiry Date</th>
        <th style="width: 8%;">Vendor</th>
        <th style="width: 6%;">Total Licenses</th>
        <th style="width: 6%;">Assigned Licenses</th>
        <th style="width: 6%;">Status</th>
        <th style="width: 8%;">Budget (ZAR)</th>
        <th style="width: 8%;">Cost (ZAR)</th>
      </tr>
    </thead>
    <tbody>
      @foreach($software as $item)
        <tr>
          <td>{{ $item->product_id ?? 'N/A' }}</td>
          <td>{{ $item->name }}</td>
          <td>{{ $item->version }}</td>
          <td>{{ $item->manufacturer ?? '-' }}</td>
          <td>{{ $item->last_updated ? \Carbon\Carbon::parse($item->last_updated)->format('Y-m-d') : 'N/A' }}</td>
          <td>{{ $item->expiry_date ? \Carbon\Carbon::parse($item->expiry_date)->format('Y-m-d') : 'N/A' }}</td>
          <td>{{ $item->vendor ?? '-' }}</td>
          <td>{{ $item->license->total_licenses ?? 0 }}</td>
          <td>{{ $item->license->assigned_licenses ?? 0 }}</td>
          <td>{{ ucfirst($item->status) }}</td>
          <td>{{ $item->budget ? 'R' . number_format($item->budget, 2) : 'N/A' }}</td>
          <td>{{ $item->cost ? 'R' . number_format($item->cost, 2) : 'N/A' }}</td>
        </tr>
      @endforeach
    </tbody>
  </table>
</body>
</html>
