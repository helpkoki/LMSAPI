@extends('layouts.admin')

@section('content')
<style>
  body {
    font-family: Arial, sans-serif;
    color: black;
    margin: 0;
    padding: 86px 14px 14px 14px;
    background-color: #3c4044ff;
  }

  .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  .table-container {
    margin-top: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
    padding: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    color: #222;
    min-width: 800px;
  }

  thead {
    background-color: #fcd34d;
    font-weight: 700;
    border-bottom: 2px solid #ccc;
    text-align: left;
  }

  th, td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
  }

  tbody tr:hover {
    background-color: #fef3c7;
  }
</style>

<div class="navbar">Licenses Expiring Within 30 Days</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>License Name</th>
                <th>Assigned To</th>
                <th>Expiry Date</th>
                <th>Days Left</th>
            </tr>
        </thead>
        <tbody>
            @forelse($licenses as $license)
                <tr>
                    <td>{{ $license->software->name ?? 'N/A' }}</td>
                    <td>{{ $license->user?->name ?? 'Unassigned' }}</td>
                    <td>{{ \Carbon\Carbon::parse($license->expiry_date)->format('d-m-Y') }}</td>
                    <td>{{ \Carbon\Carbon::parse($license->expiry_date)->diffInDays(now()) }} days</td>
                </tr>
            @empty
                <tr>
                    <td colspan="4" class="text-center">No licenses expiring in the next 30 days.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection