<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Asset Management System</title>
</head>
<body>
    <h2>Hello {{ $user->name }},</h2>
    <p>Your account has been created. Here are your login details:</p>
    <ul>
        <li>Email: {{ $user->email }}</li>
        <li>Password: {{ $password }}</li>
    </ul>
    <p>You can Login now.</p>
</body>
</html>