@extends('layouts.admin')

@section('content')
<style>
    body {
        font-family: Arial, sans-serif;
        color: black;
        margin: 0;
        padding: 20px 0 0 0; /* padding top to offset navbar */
        background-color: #3c4044ff;
    }
   
  
   
    /* Full width fixed navbar */
   .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    /* bottom-only shadow */
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
}


    .grid {
        margin-top: 40px;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 24px;
        margin-bottom: 40px;
    }
   .card {
    position: relative;
    background: rgba(255, 255, 255, 0.12);
    border-radius: 16px;
    padding: 8px 12px 12px; /* reduced padding */
    box-shadow: 0 6px 20px rgba(31, 38, 135, 0.1);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: white;
    text-align: center;
    overflow: visible;
    transition: box-shadow 0.3s ease;
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 160px; /* set a smaller minimum height */
}



.card h3 {
    font-size: 1.2rem;  /* slightly smaller */
    margin: 4px 0;
}


    .card:hover {
        box-shadow: 0 12px 48px rgba(31, 38, 135, 0.25);
    }
    .card svg.icon {
        padding: 10px;      /* smaller padding */
    height: 48px;       /* was 64px */
    width: 48px;        /* was 64px */
    margin-bottom: 8px; 
        background: rgba(240, 219, 219, 0.25);
        border-radius: 50%;
    
        stroke-width: 2.5;
        color: white;
        box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        pointer-events: none;
       
        position: relative;
        top: 0;
        left: 0;
        transform: none;
    }
    .card-blue { background: linear-gradient(135deg, #3b82f6, #2563eb, #1e40af); }
    .card-green { background: linear-gradient(135deg, #10b981, #047857, #064e3b); }
    .card-red { background: linear-gradient(135deg, #ef4444, #b91c1c, #7f1d1d); }
    .card-yellow { background: linear-gradient(135deg, #facc15, #ca8a04, #854d0e); color: #1f2937; }
    .card-indigo { background: linear-gradient(135deg, #6366f1, #4338ca, #312e81); }
    .card-purple { background: linear-gradient(135deg, #8b5cf6, #6b21a8, #4c1d95); }
    .card-teal { background: linear-gradient(135deg, #14b8a6, #0f766e, #134e4a); }
    .card-pink { background: linear-gradient(135deg, #ec4899, #be185d, #831843); }

    h3 {
        margin-top: 0;
        font-size: 1.4rem;
        font-weight: 600;
    }
    p.stat-number {
       
        font-weight: bold;
        font-size: 2rem;    /* was 3rem */
        margin-top: 6px;
    }

    .charts-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 24px;
    }
    .chart-card {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        color: #1f2937;
    }
    canvas {
        width: 100% !important;
        max-height: 400px;
    }
</style>
 
        
    
<div class="navbar">Admin Dashboard</div>

<div class="grid" style="margin-top: 80px;">
    <a href="{{ route('admin.software.index') }}" class="card card-blue" role="button" tabindex="0">
        <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round"
                d="M3 7v4a1 1 0 001 1h3m10-5h3a1 1 0 011 1v4m-5-4v8m-7-9v10m8-10v10m-6-6h4"/>
        </svg>
        <h3>Total Purchased</h3>
        <p class="stat-number">{{ $totalLicenses }}</p>
    </a>
   <a href="{{ route('admin.licenses.active') }}" class="card card-green" role="button" tabindex="0">
    <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
    </svg>
    <h3>Active Licenses</h3>
    <p class="stat-number">{{ $activeLicenses }}</p>
</a>
    <a href="{{ route('admin.licenses.expired') }}" class="card card-red" role="button" tabindex="0">
        <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
        </svg>
        <h3>Expired Licenses</h3>
        <p class="stat-number">{{ $expiredLicenses }}</p>
    </a>
  <a href="{{ route('admin.licenses.expiringSoon') }}" class="card card-yellow" role="button" tabindex="0">
    <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <circle cx="12" cy="12" r="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6l4 2"/>
    </svg>
    <h3>Expiring in 30 Days</h3>
    <p class="stat-number">{{ $expiringLicenses }}</p>
</a>
   <a href="{{ route('admin.licenses.totalCost') }}" class="card card-indigo" role="button" tabindex="0">
    <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 1v22m-4-4h8a4 4 0 00-8 0 4 4 0 008 0"/>
    </svg>
    <h3>Total Cost Spent</h3>
    <p class="stat-number">R {{ number_format($totalCost, 0, ',', ' ') }}</p>
</a>
    <a href="{{ route('admin.budget.utilization') }}" class="card card-purple" role="button" tabindex="0">
        <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 2a10 10 0 019.95 9.05L12 12z"/>
            <circle cx="12" cy="12" r="10" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <h3>Budget Utilization</h3>
        <p class="stat-number">{{ $budgetUtilization }}%</p>
    </a>
     <a href="{{ route('admin.licenses.assigned') }}" class="card card-teal" role="button" tabindex="0">
        <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <circle cx="9" cy="7" r="4" stroke-linecap="round" stroke-linejoin="round"/>
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 11v6m-4 0v-3m-4 0v3"/>
        </svg>
        <h3>Assigned Licenses</h3>
        <p class="stat-number">{{ $assignedLicenses }}</p>
    </a>
  <a href="{{ route('admin.licenses.unassigned') }}" class="card card-pink" role="button" tabindex="0">
    <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
    </svg>
    <h3>Unassigned Licenses</h3>
    <p class="stat-number">{{ $unassignedLicenses }}</p>
</a>
</div>

<div class="charts-grid">
    <div class="chart-card">
        <h3>Assigned vs Unassigned Licenses</h3>
        <canvas id="licensesChart"></canvas>
    </div>

    <div class="chart-card">
        <h3>License Cost by Manufacturer</h3>
        <canvas id="manufacturerChart"></canvas>
    </div>

    <div class="chart-card" style="grid-column: span 2;">
        <h3>Spending vs Budget Overview</h3>
        <canvas id="budgetChart"></canvas>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    new Chart(document.getElementById('licensesChart'), {
        type: 'doughnut',
        data: {
            labels: ['Assigned', 'Unassigned'],
            datasets: [{
                data: [{{ $assignedLicenses }}, {{ $unassignedLicenses }}],
                backgroundColor: ['#2563EB', '#10B981']
            }]
        }
    });

    new Chart(document.getElementById('manufacturerChart'), {
        type: 'bar',
        data: {
            labels: {!! json_encode(array_keys($manufacturerCosts)) !!},
            datasets: [{
                label: 'Cost (R)',
                data: {!! json_encode(array_values($manufacturerCosts)) !!},
                backgroundColor: '#3B82F6'
            }]
        },
        options: {
            scales: { y: { beginAtZero: true } }
        }
    });

    new Chart(document.getElementById('budgetChart'), {
        type: 'bar',
        data: {
            labels: {!! json_encode(array_keys($budgetData)) !!},
            datasets: [
                {
                    label: 'Spent',
                    data: {!! json_encode(array_column($budgetData, 'spent')) !!},
                    backgroundColor: '#EF4444'
                },
                {
                    label: 'Budget',
                    data: {!! json_encode(array_column($budgetData, 'budget')) !!},
                    backgroundColor: '#10B981'
                }
            ]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } }
        }
    });
</script>
@endpush
