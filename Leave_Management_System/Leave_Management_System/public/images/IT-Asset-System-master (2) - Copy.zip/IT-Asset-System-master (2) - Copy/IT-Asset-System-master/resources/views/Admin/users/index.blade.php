@extends('layouts.admin')

@section('content')
<style>
    /* Basic styling for the table and buttons */
    .user-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
        color: #333;
    }
    .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }


    .user-table th, 
    .user-table td {
        border: 1px solid #ccc;
        padding: 10px 12px;
        text-align: left;
    }

    .user-table thead {
        background-color: #f4f4f4;
        font-weight: bold;
    }

    .user-table tbody tr:hover {
        background-color: #e9ecef;
    }

    /* Buttons container */
    .actions {
        display: flex;
        gap: 10px;
        align-items: center;
    }

    /* Edit button */
    .btn-edit {
        background-color: #ddd;
        color: #333;
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        text-decoration: none;
    }
    .btn-edit:hover {
        background-color: #bbb;
    }

    /* Deactivate button */
    .btn-deactivate {
        background-color: #d9534f;
        color: white;
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn-deactivate:hover {
        background-color: #c9302c;
    }

    /* Activate button */
    .btn-activate {
        background-color: #5cb85c;
        color: white;
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn-activate:hover {
        background-color: #4cae4c;
    }

    /* Status styles */
    .status-active {
        color: green;
        font-weight: bold;
    }
    .status-inactive {
        color: red;
        font-weight: bold;
    }

    /* Container */
   .container {
    background-color: white;
    padding: 24px;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    margin-top: 100px;
}


    .header {
        margin-bottom: 24px;
        font-size: 24px;
        font-weight: bold;
    }

    .add-user-btn {
        float: right;
        background-color: #007bff;
        color: white;
        padding: 10px 20px;
        border-radius: 6px;
        text-decoration: none;
        margin-bottom: 20px;
    }
    .add-user-btn:hover {
        background-color: #0056b3;
    }

</style>

<div class="navbar">Users</div>

<div class="container">
    <a href="{{ route('admin.users.create') }}" class="add-user-btn">
        Add User
    </a>

    <table class="user-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Department</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($users as $user)
                <tr>
                    <td>{{ $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ ucfirst($user->role) }}</td>
                    <td>{{ $user->department }}</td>
                    <td>
                        @if($user->status === 'active')
                            <span class="status-active">Active</span>
                        @else
                            <span class="status-inactive">Inactive</span>
                        @endif
                    </td>
                    <td class="actions">
                        <a href="{{ route('admin.users.edit', $user->id) }}" class="btn-edit">
                            Edit
                        </a>

                        @if($user->status === 'active')
                            <form action="{{ route('admin.users.deactivate', $user->id) }}" method="POST" style="margin: 0;">
                                @csrf
                                @method('PATCH')
                                <button type="submit" class="btn-deactivate">Deactivate</button>
                            </form>
                        @else
                            <form action="{{ route('admin.users.activate', $user->id) }}" method="POST" style="margin: 0;">
                                @csrf
                                @method('PATCH')
                                <button type="submit" class="btn-activate">Activate</button>
                            </form>
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
