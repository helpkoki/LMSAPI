@extends('layouts.admin')

@section('content')
<style>
  body {
    font-family: Arial, sans-serif;
    color: black;
    margin: 0;
    padding: 86px 0 0 0; /* offset for navbar */
    background-color: #3c4044ff;
  }

  .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  .content-container {
    margin-left: 0;
    padding: 0 14px 14px 14px;
  }

  .table-container {
    margin-top: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
    padding: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    color: #222;
    min-width: 800px;
  }

  thead {
    background-color: #ef4444; /* red for expired */
    color: white;
    font-weight: 700;
    border-bottom: 2px solid #ccc;
    text-align: left;
  }

  th, td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
    white-space: nowrap;
  }

  tbody tr:hover {
    background-color: #b91c1c; /* darker red on hover */
    color: white;
  }
</style>

<div class="navbar">Expired Licenses</div>

<div class="content-container">
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>License Name</th>
          <th>Manufacturer</th>
          <th>Expiry Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        @forelse($expiredLicenses as $license)
          <tr>
            <td>{{ $license->software->name ?? '-' }}</td> <!-- License Name -->
            <td>{{ $license->software->manufacturer ?? '-' }}</td> <!-- Manufacturer -->
            <td>{{ \Carbon\Carbon::parse($license->expiry_date)->format('d-m-Y') ?? '-' }}</td> <!-- Expiry Date -->
            <td class="text-red-600 font-semibold">Expired</td>
          </tr>
        @empty
          <tr>
            <td colspan="4" class="text-center">No expired licenses found.</td>
          </tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection