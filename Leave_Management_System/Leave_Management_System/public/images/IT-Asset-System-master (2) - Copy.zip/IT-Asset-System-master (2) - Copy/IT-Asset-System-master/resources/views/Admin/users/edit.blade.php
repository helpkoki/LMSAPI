@extends('layouts.admin')

@section('content')
<h1 class="text-2xl font-bold mb-6">Edit User</h1>

<form action="{{ route('admin.users.update', $user->id) }}" method="POST" class="bg-white p-6 rounded-xl shadow max-w-lg">
    @csrf
    @method('PUT')

    <div class="mb-4">
        <label class="block font-semibold">Name</label>
        <input type="text" name="name" value="{{ $user->name }}" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Email</label>
        <input type="email" name="email" value="{{ $user->email }}" class="w-full border rounded px-3 py-2" required>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Password (leave blank if unchanged)</label>
        <input type="password" name="password" class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Role</label>
        <select name="role" class="w-full border rounded px-3 py-2">
            <option value="admin" {{ $user->role === 'admin' ? 'selected' : '' }}>Admin</option>
            <option value="viewer" {{ $user->role === 'viewer' ? 'selected' : '' }}>Viewer</option>
        </select>
    </div>

    <div class="mb-4">
        <label class="block font-semibold">Status</label>
        <select name="status" class="w-full border rounded px-3 py-2">
            <option value="active" {{ $user->status === 'active' ? 'selected' : '' }}>Active</option>
            <option value="inactive" {{ $user->status === 'inactive' ? 'selected' : '' }}>Inactive</option>
        </select>
    </div>

    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
        Update
    </button>
    <a href="{{ route('admin.users.index') }}" class="ml-2 text-gray-600 hover:underline">Cancel</a>
</form>
@endsection