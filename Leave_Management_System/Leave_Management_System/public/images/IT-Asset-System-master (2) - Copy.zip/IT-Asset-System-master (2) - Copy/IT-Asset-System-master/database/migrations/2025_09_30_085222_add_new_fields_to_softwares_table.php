<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('software', function (Blueprint $table) {
            $table->string('product_id')->nullable()->after('id');
            $table->string('number_of_installations')->nullable()->after('manufacturer');
            $table->string('assigned_to')->nullable()->after('vendor');
            $table->integer('total_licenses')->default(0)->after('assigned_to');
            $table->integer('assigned_licenses')->default(0)->after('total_licenses');
            $table->decimal('renewal_cost', 10, 2)->nullable()->after('status');
            $table->decimal('cost', 10, 2)->nullable()->after('renewal_cost');
        });
    }

    public function down(): void
    {
        Schema::table('software', function (Blueprint $table) {
            $table->dropColumn([
                'product_id',
                'number_of_installations',
                'assigned_to',
                'total_licenses',
                'assigned_licenses',
                'renewal_cost',
                'cost',
            ]);
        });
    }
};
